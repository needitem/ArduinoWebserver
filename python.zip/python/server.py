import PythonServer

server = PythonServer.PythonServer(port=8000)

server.run()