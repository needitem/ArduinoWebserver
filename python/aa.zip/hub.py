import pythonhub

hub = pythonhub.PythonHub()
hub.run()

del hub
