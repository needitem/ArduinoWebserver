import pythonhub

hub = pythonhub.PythonHub()

hub.writeSerial("get", "volt")
hub.clearSerial
